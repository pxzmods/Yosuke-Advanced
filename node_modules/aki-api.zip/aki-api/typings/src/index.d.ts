import Aki, { answers } from './Akinator';
import { regions, region } from './constants/Client';
export { Aki, regions, region, answers };
